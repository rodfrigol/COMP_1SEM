function [Kp, Kpsi] = questao5()
% Calcule os valores de Kp e Kpsi para que o sistema atenda aos requisitos
% no dominio da frequencia.

Kpsi = 6.27;
Kp = 4.35;

end
