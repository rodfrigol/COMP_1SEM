function erroRegime = questao2(m, b, Kp, Ki)
% Determine o erro em regime para uma perturbacao rampa no caso do sistema
% de cruise control com controlador PI.

% erroRegime = ...

erroRegime = -1/Ki;

end
