function limites = questao1()
% Determinar a faixa de valores de K tal que o sistema apresentado na
% na figura seja estavel.

% a = ...;
% b = ...;
% limites = [a, b];

a = -4.8;
b = 42;

limites = [a, b];

end
