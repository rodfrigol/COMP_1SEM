function [eInf, tr, ts] = questao4()
% Para o sistema
% Gf = 1 / ((s + 10) * (s + 20) * (s^2 + s + 4)),
% determine:
% eInf: erro em regime para entrada de degrau.
% tr: tempo de subidade de 10% a 90%.
% ts: tempo de acomodacao de 2%.

% eInf = ...
% tr = ...
% ts = ...

eInf = 799/800;
tr = 0.84;
ts = 3.9;

end
