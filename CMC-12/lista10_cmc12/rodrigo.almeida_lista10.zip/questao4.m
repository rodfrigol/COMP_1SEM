function [wcp, ganhoPM] = questao4()
% Determinar analiticamente a frequencia de cruzamento wcp e o ganho de
% margem de fase ganhoPM devido a troca do sensor.

wcp = 7.3;
ganhoPM = 29.3;

end