function [GM, PM] = questao3()
% Determinar graficamente a margem de ganho GM e a margem de fase PM.

GM = 16
PM = 75

end