function [K, z, p] = questao3()
% Projetar controlador com funcao de transferencia
% C(s) = K * (s - z) / (s * (s - p)).

K = 1;
p = 0;
z = 1363,12;

end