function [alpha, T] = questao2()
% Projete a compensacao lag para reduzir o erro em regime pela metade.
% Considere a compensacao lag na seguinte forma:
% Clag = alpha * (T * s + 1) / (alpha * T * s + 1).

alpha = 2.11111;
T = 1.45007;

end