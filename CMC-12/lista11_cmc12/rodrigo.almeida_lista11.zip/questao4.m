function deltaPM = questao4()
% Calcule a perda de margem de fase provocada pelos atrasos na malha.
% Retorne um valor positivo.

deltaPM = 55.32;

end