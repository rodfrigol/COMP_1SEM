function [Kp, Ki] = questao4()
% Projetar um controlador PI para alocar polos complexo-conjugados em
% posicoes tais que wn = 6 rad/s e xi = 0.7.

Kp = 8339.6;
Ki = 36743.4;

end
