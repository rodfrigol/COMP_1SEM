function K = questao3()
% Determinar K para se ter Mp = 0.0432.

K = 3.308;

end
